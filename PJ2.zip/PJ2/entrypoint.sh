#!/bin/bash
echo "starting the container"
exec service nginx status
exec service nginx start
